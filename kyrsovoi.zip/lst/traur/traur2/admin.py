from django.contrib import admin
from .models import Task
from .models import Product

admin.site.register(Task)
admin.site.register(Product)

# Register your models here.
