from django.urls import path

from traur import settings
from django.conf.urls.static import static

from .views import *


urlpatterns = [
    path('', main, name = "home"),
    path('catalog/', catalog, name = "catalog"),
    path('kontact/', kontact, name = "kontact"),
    path('reg/', reg, name = "reg"),
    path('vhod/', vhod, name = "vhod"),
    #path("review/<int:pk>/", AddReview.as_view(), name="add_review"),
    path("product/<int:pk>", detail_view, name="product_detail"),
]   + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

    