from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from .models import Task,Product
from django.views.generic.detail import DetailView
from .forms import TaskForm



def main(request):
    return render(request, 'traur2/main.html')

def reg(request):
    return render(request, 'traur2/reg.html')

def catalog(request):
    pr = Product.objects.all()
    return render(request, 'traur2/catalog.html', {"pr":pr})

def kontact(request):
    com=Task.objects.order_by("-id")
    error = ''
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            form = form.save(commit=False)
            #form.user = request.user
            form.name_id = request.user.id
            form.save()
            return redirect('kontact')
        else:
            error = 'Форма неверна!'

    form = TaskForm()
    context = {
        'form': form,
        'error': error,
        "Макарlegend":com
    }

    return render(request, 'traur2/kontact.html', context)



def vhod(request):
    return render(request, 'traur2/vhod.html')

def product_detail(request):
    return render(request, 'traur2/product_detail.html')

def detail_view(request, pk):
    ee=get_object_or_404(Product,pk=pk)
    return render(request, 'traur2/product_detail.html', context={'ee': ee})



 
"""
class AddReview(View):
    def post(self, request, pk):
        form = ReviewForm(request.POST)
        if form.is_valid():
            form = form.save(commit=False)
            form.movie_id = pk
            form.save()
        return redirect("/")
"""
