from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Task(models.Model):
    name = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(default=timezone.now)
    text = models.TextField('Комментарий')
    

    

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'

class Product(models.Model):

    CH = {
        "category1":"category1",
        "category2":"category2",
    }

    photo = models.ImageField(
        upload_to="photos",
        default=None, blank=True,
        null=True, verbose_name="Фото"
    )
    name = models.CharField('Наименование продукта', max_length = 200)
    price = models.IntegerField()
    cat = models.CharField(max_length = 20, choices=CH, default="")

    class Meta:
        verbose_name = 'продукт'
        verbose_name_plural = 'Продукты'

    @property
    def photo_url(self):
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url

    def str(self):
        return self.name
"""
class Reviews(models.Model):
    email = models.EmailField()
    name = models.CharField(max_length=100)
    text = models.TextField("Сообщение", )
    parent = models.ForeignKey(
        'self', verbose_name="Родитель", on_delete=models.SET_NULL, blank=True, null=True
    )

    def __str__(self):
        return f"{self.name}"

    class Meta:
        verbose_name = "Отзыв"
        verbose_name_plural = "Отзывы"
"""

