from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from . import Task

class TaskModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        test_user = User.objects.create_user(username='testuser', password='12345')
        Task.objects.create(name=test_user, date=timezone.now(), text='Test task')

    def test_name_label(self):
        task = Task.objects.get(id=1)
        field_label = task._meta.get_field('name').verbose_name
        self.assertEquals(field_label, 'name')

    def test_text_max_length(self):
        task = Task.objects.get(id=1)
        max_length = task._meta.get_field('text').max_length
        self.assertEquals(max_length, 200)
