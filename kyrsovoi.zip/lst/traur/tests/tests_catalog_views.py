from django.test import TestCase, Client
from django.urls import reverse

class TestCatalogViews(TestCase):
    def setUp(self):
        self.client = Client()
        self.catalog_url = reverse('catalog')

    def test_catalog_GET(self):
        response = self.client.get(self.catalog_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'traur2/catalog.html')
