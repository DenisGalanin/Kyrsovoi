from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User

class TestKontactViews(TestCase):
    def setUp(self):
        self.client = Client()
        self.kontact_url = reverse('kontact')
        self.user = User.objects.create_user(username='testuser', password='12345')

    def test_kontact_GET(self):
        self.client.login(username='testuser', password='12345')
        response = self.client.get(self.kontact_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'traur2/kontact.html')
