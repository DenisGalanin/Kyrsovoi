from django.test import TestCase
from . import Product

class ProductModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        Product.objects.create(name='Test Product', price=100, cat='category1')

    def test_name_label(self):
        product = Product.objects.get(id=1)
        field_label = product._meta.get_field('name').verbose_name
        self.assertEquals(field_label, 'Наименование продукта')

    def test_price_positive(self):
        product = Product.objects.get(id=1)
        self.assertTrue(product.price >= 0)
