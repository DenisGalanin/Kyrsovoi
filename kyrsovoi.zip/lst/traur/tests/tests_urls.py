from django.test import SimpleTestCase
from django.urls import reverse, resolve
from .views import main, catalog, kontact, reg, vhod, detail_view
from django.conf import settings
from django.conf.urls.static import static

class TestUrls(SimpleTestCase):

    def test_main_url_resolves(self):
        url = reverse('home')
        self.assertEquals(resolve(url).func, main)

    def test_catalog_url_resolves(self):
        url = reverse('catalog')
        self.assertEquals(resolve(url).func, catalog)

    def test_kontact_url_resolves(self):
        url = reverse('kontact')
        self.assertEquals(resolve(url).func, kontact)

    def test_reg_url_resolves(self):
        url = reverse('reg')
        self.assertEquals(resolve(url).func, reg)

    def test_vhod_url_resolves(self):
        url = reverse('vhod')
        self.assertEquals(resolve(url).func, vhod)

    def test_product_detail_url_resolves(self):
        url = reverse('product_detail', args=[1])  # assuming there's a product with pk=1
        self.assertEquals(resolve(url).func, detail_view)

    def test_static_url(self):
        self.assertEquals(settings.MEDIA_URL, '/media/')
        self.assertEquals(settings.MEDIA_ROOT, 'path/to/media/root/')

    def test_static_url_configuration(self):
        static_url = static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
        self.assertEqual(static_url, ['/media/'])
