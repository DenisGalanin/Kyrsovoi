from django.test import TestCase, Client
from django.urls import reverse

class TestMainViews(TestCase):
    def setUp(self):
        self.client = Client()
        self.main_url = reverse('main')

    def test_main_GET(self):
        response = self.client.get(self.main_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'traur2/main.html')
